package com.file.firebasedemo

import android.content.Intent
import android.media.MediaPlayer.OnCompletionListener
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.se.omapi.SEService.OnConnectedListener
import android.widget.Toast
import com.file.firebasedemo.databinding.ActivityMainBinding
import com.google.android.gms.auth.api.Auth
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.auth.api.signin.GoogleSignInResult
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.common.api.internal.OnConnectionFailedListener
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuth.AuthStateListener
import com.google.firebase.auth.GoogleAuthProvider

class MainActivity : AppCompatActivity(), GoogleApiClient.OnConnectionFailedListener{
    var binding: ActivityMainBinding? = null
    var fireBaseAuth: FirebaseAuth? = null
    var authBtnListener: AuthStateListener? = null
    var googleApiClient: GoogleApiClient? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        fireBaseAuth = FirebaseAuth.getInstance()
        authBtnListener = FirebaseAuth.AuthStateListener(object : AuthStateListener, (FirebaseAuth) -> Unit{
            override fun onAuthStateChanged(firebaseAuth: FirebaseAuth) {
                var user = firebaseAuth.currentUser
                if(user != null){
                    Toast.makeText(this@MainActivity, user.displayName, Toast.LENGTH_SHORT).show()
                }
            }

            override fun invoke(p1: FirebaseAuth) {

            }

        })

        var googleSignOpt = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(resources.getString(R.string.web_client_id))
            .requestEmail()
            .build()

        googleApiClient = GoogleApiClient.Builder(this)
            .enableAutoManage(this, this)
            .addApi(Auth.GOOGLE_SIGN_IN_API,googleSignOpt)
            .build()

        binding!!.signIn.setOnClickListener{
            var intent = Auth.GoogleSignInApi.getSignInIntent(googleApiClient!!)
            startActivityForResult(intent,10)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode == RESULT_OK){
            if(requestCode == 10){
                var result = Auth.GoogleSignInApi.getSignInResultFromIntent(data!!)
                handleResult(result)
            }
        }
    }

    fun handleResult(result: GoogleSignInResult?){
        if(result!!.isSuccess){
            var account = result.signInAccount
            var credential = GoogleAuthProvider.getCredential(account!!.idToken, null)
            loginFireBase(credential)
        } else {
            Toast.makeText(this,"Login Failure", Toast.LENGTH_SHORT).show()
        }
    }

    fun loginFireBase(credential: AuthCredential){
        fireBaseAuth!!.signInWithCredential(credential)
            .addOnCompleteListener(this@MainActivity,object :OnCompleteListener<AuthResult>{
                override fun onComplete(p0: Task<AuthResult>) {
                    if (p0.isSuccessful){
                        Toast.makeText(this@MainActivity, "Login Success", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, "Login Failure", Toast.LENGTH_SHORT).show()
                    }
                }

            })
    }


    override fun onConnectionFailed(p0: ConnectionResult) {

    }
}